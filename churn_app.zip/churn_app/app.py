"""app.py - Flask backend for the Customer Churn Predictor."""
import json
import os

import joblib
import pandas as pd
from flask import Flask, render_template, request

# Absolute paths so the app also works on PythonAnywhere (different working dir)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model = joblib.load(os.path.join(BASE_DIR, "model.joblib"))      # preprocessing + model
with open(os.path.join(BASE_DIR, "features.json")) as f:
    META = json.load(f)
FEATURES = META["features"]                                       # exact training order

app = Flask(__name__)

YES_NO = ["Yes", "No"]
FIELDS = {   # name -> allowed options (dropdowns); numeric fields handled separately
    "gender": ["Female", "Male"],
    "SeniorCitizen": ["0", "1"],
    "Partner": YES_NO,
    "Dependents": YES_NO,
    "PhoneService": YES_NO,
    "MultipleLines": ["No", "Yes", "No phone service"],
    "InternetService": ["DSL", "Fiber optic", "No"],
    "OnlineSecurity": ["No", "Yes", "No internet service"],
    "OnlineBackup": ["No", "Yes", "No internet service"],
    "DeviceProtection": ["No", "Yes", "No internet service"],
    "TechSupport": ["No", "Yes", "No internet service"],
    "StreamingTV": ["No", "Yes", "No internet service"],
    "StreamingMovies": ["No", "Yes", "No internet service"],
    "Contract": ["Month-to-month", "One year", "Two year"],
    "PaperlessBilling": YES_NO,
    "PaymentMethod": ["Electronic check", "Mailed check",
                      "Bank transfer (automatic)", "Credit card (automatic)"],
}
LABELS = {
    "gender": "Gender", "SeniorCitizen": "Senior citizen (1 = yes, 0 = no)",
    "Partner": "Has a partner", "Dependents": "Has dependents",
    "PhoneService": "Phone service", "MultipleLines": "Multiple phone lines",
    "InternetService": "Internet service", "OnlineSecurity": "Online security",
    "OnlineBackup": "Online backup", "DeviceProtection": "Device protection",
    "TechSupport": "Tech support", "StreamingTV": "Streaming TV",
    "StreamingMovies": "Streaming movies", "Contract": "Contract type",
    "PaperlessBilling": "Paperless billing", "PaymentMethod": "Payment method",
}


def validate(form):
    """Return (clean_row_dict, list_of_error_messages)."""
    errors, row = [], {}
    for name, options in FIELDS.items():
        value = form.get(name, "").strip()
        if not value:
            errors.append(f"Please choose a value for “{LABELS[name]}”.")
        elif value not in options:
            errors.append(f"“{value}” is not a valid option for “{LABELS[name]}”.")
        else:
            row[name] = value

    def number(name, label, lo, hi, required=True):
        raw = form.get(name, "").strip()
        if not raw:
            if required:
                errors.append(f"Please enter {label}.")
            return None
        try:
            val = float(raw)
        except ValueError:
            errors.append(f"{label.capitalize()} must be a number.")
            return None
        if not (lo <= val <= hi):
            errors.append(f"{label.capitalize()} must be between {lo} and {hi}.")
            return None
        return val

    tenure = number("tenure", "tenure in months", 0, 120)
    monthly = number("MonthlyCharges", "monthly charges", 0, 1000)
    total = number("TotalCharges", "total charges", 0, 100000, required=False)
    if tenure is not None and monthly is not None and total is None:
        total = round(tenure * monthly, 2)       # estimate when left blank

    if errors:
        return None, errors

    row.update({"SeniorCitizen": int(row["SeniorCitizen"]), "tenure": tenure,
                "MonthlyCharges": monthly, "TotalCharges": total})
    # Consistency checks between related answers
    if row["PhoneService"] == "No" and row["MultipleLines"] == "Yes":
        errors.append("Multiple lines can't be “Yes” when there is no phone service.")
    if row["InternetService"] == "No" and any(
            row[c] == "Yes" for c in ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                                      "TechSupport", "StreamingTV", "StreamingMovies"]):
        errors.append("Internet add-ons can't be “Yes” when there is no internet service.")
    return (row, errors) if not errors else (None, errors)


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", fields=FIELDS, labels=LABELS, values={}, errors=[], result=None)


@app.route("/predict", methods=["POST"])
def predict():
    values = request.form.to_dict()
    row, errors = validate(request.form)
    if errors:
        return render_template("index.html", fields=FIELDS, labels=LABELS,
                               values=values, errors=errors, result=None), 400
    try:
        df = pd.DataFrame([row])[FEATURES]            # same column order as training
        pred = int(model.predict(df)[0])
        prob = float(model.predict_proba(df)[0][1])
    except Exception:
        app.logger.exception("Prediction failed")
        return render_template("index.html", fields=FIELDS, labels=LABELS, values=values,
                               errors=["Something went wrong while predicting. Please check the values and try again."],
                               result=None), 500
    result = {"churn": pred == 1, "probability": round(prob * 100, 1)}
    return render_template("index.html", fields=FIELDS, labels=LABELS,
                           values=values, errors=[], result=result)


if __name__ == "__main__":
    app.run(debug=True)
