# Paste this into the PythonAnywhere WSGI file (Web tab -> WSGI configuration file).
# Replace YOURUSERNAME and the folder name with yours.
import sys

path = "/home/YOURUSERNAME/churn_app"
if path not in sys.path:
    sys.path.insert(0, path)

from app import app as application   # PythonAnywhere looks for the name "application"
