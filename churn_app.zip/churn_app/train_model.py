"""
train_model.py  -  Run ONCE on your own computer (not on PythonAnywhere).

Reuses the Assignment 1 workflow: clean data -> preprocess -> compare models
-> pick the best -> save ONE pipeline file (preprocessing + model together).
Saving them together guarantees the website applies exactly the same
encoding, scaling and feature order as training.

Usage:  python train_model.py data/WA_Fn-UseC_-Telco-Customer-Churn.xlsx
"""
import sys
import json
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

path = sys.argv[1] if len(sys.argv) > 1 else "data/WA_Fn-UseC_-Telco-Customer-Churn.xlsx"
df = pd.read_excel(path) if path.endswith((".xlsx", ".xls")) else pd.read_csv(path)

# ---------- 1. Cleaning (same as Assignment 1) ----------
df = df.drop(columns=["customerID"], errors="ignore")
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df["TotalCharges"] = df["TotalCharges"].fillna(0)          # new customers (tenure 0)
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})
df = df.dropna(subset=["Churn"])

# ---------- 2. Features (ORDER MATTERS - saved to features.json) ----------
NUMERIC = ["SeniorCitizen", "tenure", "MonthlyCharges", "TotalCharges"]
CATEGORICAL = [
    "gender", "Partner", "Dependents", "PhoneService", "MultipleLines",
    "InternetService", "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies", "Contract",
    "PaperlessBilling", "PaymentMethod",
]
FEATURES = NUMERIC + CATEGORICAL
X, y = df[FEATURES], df["Churn"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# ---------- 3. Preprocessing: scale numbers, one-hot encode text ----------
pre = ColumnTransformer([
    ("num", StandardScaler(), NUMERIC),
    ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
])

# ---------- 4. Compare candidate models ----------
candidates = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                            random_state=42, n_jobs=-1),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
}
results, best_name, best_pipe, best_score = {}, None, None, -1
for name, clf in candidates.items():
    pipe = Pipeline([("prep", pre), ("model", clf)]).fit(X_train, y_train)
    pred = pipe.predict(X_test)
    proba = pipe.predict_proba(X_test)[:, 1]
    results[name] = {
        "accuracy": round(accuracy_score(y_test, pred), 4),
        "f1_churn": round(f1_score(y_test, pred), 4),
        "roc_auc": round(roc_auc_score(y_test, proba), 4),
    }
    print(f"{name:20s} {results[name]}")
    if results[name]["roc_auc"] > best_score:       # selection metric: ROC-AUC
        best_name, best_pipe, best_score = name, pipe, results[name]["roc_auc"]

# NOTE: If Assignment 1 picked a different model/hyper-parameters, edit
# `candidates` above so that it matches YOUR Assignment 1 result.

print(f"\nBest model: {best_name}")
print(classification_report(y_test, best_pipe.predict(X_test),
                            target_names=["No Churn", "Churn"]))

# ---------- 5. Save artifacts ----------
joblib.dump(best_pipe, "model.joblib")
with open("features.json", "w") as f:
    json.dump({"features": FEATURES, "numeric": NUMERIC, "categorical": CATEGORICAL,
               "best_model": best_name, "metrics": results[best_name]}, f, indent=2)
print("Saved model.joblib and features.json")
