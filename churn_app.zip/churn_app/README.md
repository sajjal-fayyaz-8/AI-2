# Customer Churn Predictor (Flask)

## Structure
```
churn_app/
  app.py                  Flask backend (routes, validation, prediction)
  train_model.py          Trains + compares models, saves model.joblib + features.json
  model.joblib            (created by train_model.py)  preprocessing + model in one Pipeline
  features.json           (created by train_model.py)  feature order + best model info
  requirements.txt
  wsgi_pythonanywhere.py  Text to paste into the PythonAnywhere WSGI file
  templates/index.html
  static/style.css
  data/                   Put WA_Fn-UseC_-Telco-Customer-Churn.xlsx here (local only)
```

## A. Run locally
1. `pip install -r requirements.txt`
2. Copy the dataset into `data/`
3. `python train_model.py data/WA_Fn-UseC_-Telco-Customer-Churn.xlsx`
4. `python app.py`  then open http://127.0.0.1:5000
5. Test one likely-churn customer (month-to-month, fiber, tenure 2, ~$95, electronic check)
   and one likely-stay customer (two-year, tenure 60, ~$25, DSL).

## B. Deploy on PythonAnywhere
1. Create a free account at pythonanywhere.com (your username becomes `username.pythonanywhere.com`).
2. **Files** tab -> upload (or upload a ZIP and unzip in a Bash console) so you have
   `/home/USERNAME/churn_app/` containing app.py, model.joblib, features.json, templates/, static/.
   You do NOT need the dataset or train_model.py online.
3. **Consoles -> Bash**:
   ```
   cd ~/churn_app
   pip install --user -r requirements.txt     # or use a virtualenv
   ```
   Check versions match local: `pip show scikit-learn` on both machines.
   If they differ, retrain on PythonAnywhere or install the same version.
4. **Web** tab -> *Add a new web app* -> Manual configuration -> Flask / same Python version you used in the console.
5. Edit the **WSGI configuration file** and replace its contents with `wsgi_pythonanywhere.py`
   (change YOURUSERNAME).
6. (Optional) Static files: URL `/static/` -> Directory `/home/USERNAME/churn_app/static`.
7. Click **Reload**, then open `https://USERNAME.pythonanywhere.com` from your phone to confirm.
8. If it fails: Web tab -> **Error log**.

## C. Input -> prediction flow (for your viva)
1. Browser submits the HTML form (POST /predict).
2. `validate()` checks every field: missing, not in allowed options, non-numeric, out of range, contradictory.
3. Valid values become a one-row DataFrame with columns in the exact training order (`features.json`).
4. `model.joblib` is a scikit-learn Pipeline: ColumnTransformer (StandardScaler on numbers,
   OneHotEncoder on categories) followed by the classifier -> identical preprocessing to training.
5. `predict()` gives 0/1, `predict_proba()` gives the churn probability.
6. Flask renders index.html showing "Churn"/"No Churn" and the percentage, never raw arrays.
